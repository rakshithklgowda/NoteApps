const mongoose = require("mongoose")
const validator = require("validator")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const userSchema = new mongoose.Schema({
    username : {
        type : String,
        required : true,
        trim : true
    },
  
    password : {
        type : String,
        required : true,
        trim : true,
        minlength : 7,
        validate(value){
            if(value.toLowerCase().includes("password")){
                throw new Error("invalid password value")
            }
        }
    },
    roles : {
        type : String,
        // required : true,
        trim : true
    },
    tokens : [{
        token : {
            type:String,
            required:true
        }
    }],
    avatar : {
        type : Buffer
    }
},{
    timestamps : true
})

userSchema.methods.generateAuthToken = async function(){
    const User = this
    const token = await jwt.sign({_id : User._id.toString()},"secretkey")

    User.tokens = User.tokens.concat({token})
    await User.save()
    return token

}
userSchema.statics.findByCredentials = async (username,password) => {

    const User = await user.findOne({username})
    if(!User){
        throw new Error("unable to login")
    }
    const isMatch = await bcrypt.compare(password,User.password)
    if(!isMatch){
        throw new Error("unable to login")
    }
    return User
}

userSchema.pre("save",async function(next) {

     const User = this
     if(User.isModified('password')){
        User.password = await bcrypt.hash(User.password,8)
     }
    next()
})

userSchema.pre("remove", async function(next) {
   const user = this
   await Task.deleteMany({owner : user._id})
   next()
})
const user = mongoose.model('user',userSchema)
module.exports = user